<?php
require('functions.php');
$name = 'About';
require('views/about.view.php');
